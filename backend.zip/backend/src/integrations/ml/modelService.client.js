import { env } from "../../config/env.js";
import { AppError } from "../../errors/AppError.js";

function requireProviderContract(serviceName, serviceUrl) {
  if (!serviceUrl) {
    throw new AppError(
      503,
      "MODEL_SERVICE_NOT_CONFIGURED",
      `${serviceName} service URL is not configured`,
    );
  }

  throw new AppError(
    503,
    "MODEL_CONTRACT_UNAVAILABLE",
    `${serviceName} is unavailable until its provider contract is supplied and verified`,
  );
}

export async function requestVoiceToJsonModel() {
  return requireProviderContract("Voice-to-JSON model", env.ML_VOICE_SERVICE_URL);
}

export async function requestCollectionStrategyModel() {
  return requireProviderContract("Collection strategy model", env.ML_STRATEGY_SERVICE_URL);
}
