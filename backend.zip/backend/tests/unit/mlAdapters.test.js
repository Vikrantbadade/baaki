import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { env } = vi.hoisted(() => ({
  env: {
    ML_VOICE_SERVICE_URL: undefined,
    ML_STRATEGY_SERVICE_URL: undefined,
    ML_SERVICE_AUTH_TOKEN: undefined,
  },
}));

vi.mock("../../src/config/env.js", () => ({ env }));

import {
  requestCollectionStrategyModel,
  requestVoiceToJsonModel,
} from "../../src/integrations/ml/modelService.client.js";

describe("ML provider adapters", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  beforeEach(() => {
    env.ML_VOICE_SERVICE_URL = undefined;
    env.ML_STRATEGY_SERVICE_URL = undefined;
    env.ML_SERVICE_AUTH_TOKEN = undefined;
  });

  it("returns a clear 503 when a provider URL is not configured", async () => {
    await expect(requestVoiceToJsonModel()).rejects.toMatchObject({
      status: 503,
      code: "MODEL_SERVICE_NOT_CONFIGURED",
    });
  });

  it("does not guess transport behavior or fabricate output before the provider contract is available", async () => {
    env.ML_VOICE_SERVICE_URL = "https://voice.example.test";
    env.ML_STRATEGY_SERVICE_URL = "https://strategy.example.test";
    env.ML_SERVICE_AUTH_TOKEN = "test-auth-token";
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);

    const voiceError = requestVoiceToJsonModel();
    const strategyError = requestCollectionStrategyModel();
    await expect(voiceError).rejects.toMatchObject({
      status: 503,
      code: "MODEL_CONTRACT_UNAVAILABLE",
    });
    await expect(strategyError).rejects.toMatchObject({
      status: 503,
      code: "MODEL_CONTRACT_UNAVAILABLE",
    });

    expect(fetchMock).not.toHaveBeenCalled();
  });
});
